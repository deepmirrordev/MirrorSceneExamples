﻿using System.Collections.Generic;
using UnityEngine;

namespace MirrorVerse.UI.Renderers
{
    public class SceneRendererImpl : SceneRenderer
    {
        public XrPlatformAdapter xrPlatformAdapter;

        [HideInInspector]
        public MarkerRenderer markerRenderer;
        [HideInInspector]
        public MinimapRenderer minimapRenderer;

        [HideInInspector]
        public GameObject immediateRoot;
        [HideInInspector]
        public PointCloudRenderer pointCloudRenderer;
        [HideInInspector]
        public ImmediateMeshRenderer immediateMeshRenderer;
        [HideInInspector]
        public ImmediateMeshRenderer minimapMeshRenderer;
        [HideInInspector]
        public ScanLineRenderer scanLineRenderer;
        [HideInInspector]
        public RaycastRenderer raycastRenderer;
        [HideInInspector]
        public StaticMeshRenderer staticMeshRenderer;
        [HideInInspector]
        public NavMeshRenderer navMeshRenderer;

        // Experiments
        [HideInInspector]
        public TrajectoryRenderer trajectoryRenderer;
        [HideInInspector]
        public DetectedBoxRenderer immediateBoxRenderer;
        [HideInInspector]
        public DetectedBoxRenderer staticBoxRenderer;
        [HideInInspector]
        public AirWallRenderer airWallRenderer;

        private GameObject _cameraObject;
        private string _currentClientId;
        private string _hostClientId;
        private bool _capturing;
        private int _registeredImageCount;
        private Dictionary<string, ClientStreamRenderable> _allClientStreams = new();

        private void Start()
        {
            // Note: there are several sub render objects as children of this visual artifact renderer.
            // The root transform of visual artifacts renderer will change when session has a fused pose.
            // Then all children rednerers will follow the root transform.

            // Here constructs the sub renderers with given renderer options customized by applications
            // Note that names of the game object are fixed. Do not change them in the scene.
            /* - CoreRenderer (Component)
                  - CanvasRoot
                      - MarkerCanvas
                      - MinimapCanvas
                  - ImmediateRoot  // This root's transform in Unity scene is controlled by server during streaming.
                      - PointClouds
                      - ImmediateMesh
                      - MinimapMesh (different layer mask)
                      - Trajectories  (experiment)
                      - ImmediateBox  (experiment)
                      - ...
                  - RaycastCursor  // Rest of the object's transforms should be always set to identity.
                  - ScanLine
                  - StaticMesh     
                  - NavMesh
                  - StaticBox (experiment)
                  - AirWall   (experiment)
            */

            // The client ID is generated when a new capture is started.
            _currentClientId = null;
            _hostClientId = null;
            _capturing = false;

            if (xrPlatformAdapter == null)
            {
                Debug.LogWarning(
                    "Warning: XR Platform Adapter instance is not set. All following rendering logic are aborted." +
                    $"Please check if 'XR Platform Adapter' property is correctly assigned.");
                return;
            }

            if (xrPlatformAdapter != null)
            {
                _cameraObject = xrPlatformAdapter.GetCameraObject();
            }

            // Automatically finds all necessary child components based.

            immediateRoot = transform.Find("ImmediateRoot")?.gameObject;
            
            pointCloudRenderer = transform.Find("ImmediateRoot/PointClouds")?.GetComponent<PointCloudRenderer>();
            pointCloudRenderer?.SetCameraObject(_cameraObject);

            immediateMeshRenderer = transform.Find("ImmediateRoot/ImmediateMesh")?.GetComponent<ImmediateMeshRenderer>();
            
            minimapMeshRenderer = transform.Find("ImmediateRoot/MinimapMesh")?.GetComponent<ImmediateMeshRenderer>();
            
            staticMeshRenderer = transform.Find("StaticMesh")?.GetComponent<StaticMeshRenderer>();
            
            navMeshRenderer = transform.Find("NavMesh")?.GetComponent<NavMeshRenderer>();
            
            raycastRenderer = transform.Find("RaycastCursor")?.GetComponent<RaycastRenderer>();
            raycastRenderer?.SetXrPlatformAdapter(xrPlatformAdapter);

            scanLineRenderer = transform.Find("ScanLine")?.GetComponent<ScanLineRenderer>();
            
            markerRenderer = transform.Find("CanvasRoot/MarkerCanvas")?.GetComponent<MarkerRenderer>();
            
            minimapRenderer = transform.Find("CanvasRoot/MinimapCanvas")?.GetComponent<MinimapRenderer>();
            minimapRenderer?.SetArCameraObject(_cameraObject);

            // Experiments
            trajectoryRenderer = transform.Find("ImmediateRoot/Trajectories")?.GetComponent<TrajectoryRenderer>();
            immediateBoxRenderer = transform.Find("ImmediateRoot/ImmediateBox")?.GetComponent<DetectedBoxRenderer>();
            staticBoxRenderer = transform.Find("StaticBox")?.GetComponent<DetectedBoxRenderer>();
            airWallRenderer = transform.Find("AirWall")?.GetComponent<AirWallRenderer>();
        }

        public override void SetCapturing(bool capturing, string currentClientId = null, string hostClientId = null)
        {
            _capturing = capturing;
            if (capturing)
            {
                _currentClientId = currentClientId;

                if (!string.IsNullOrWhiteSpace(hostClientId))
                {
                    _hostClientId = hostClientId;
                }
                else
                {
                    // If given host client ID is null, current device is host.
                    _hostClientId = _currentClientId;
                }

                Debug.Log($"Capturing stream is started. Current cleint ID: {_currentClientId}, host client ID: {_hostClientId}");

                // Show minimap
                if (minimapRenderer != null && minimapRenderer.options.enabled)
                {
                    minimapRenderer.UpdateCurrentClient(_currentClientId);
                    minimapRenderer.ToggleVisibility(true);
                }

                // Start scanline effect
                if (scanLineRenderer != null)
                {
                    scanLineRenderer.StartEffect(_cameraObject.transform);
                }
            }
            else
            {
                // Hide minimap
                if (minimapRenderer != null)
                {
                    minimapRenderer.ToggleVisibility(false);
                    minimapRenderer.ClearAll();
                }
                // Stop scanline effect
                if (scanLineRenderer != null)
                {
                    scanLineRenderer.StopEffect();
                }
            }
        }

        public override bool IsCapturing()
        {
            return _capturing;
        }

        public override void UpdateSceneOriginOffset(Pose sceneOriginOffset)
        {
            // Set the immediate root to scene origin offset.
            immediateRoot.transform.SetPositionAndRotation(sceneOriginOffset.position, sceneOriginOffset.rotation);
        }

        public override void UpdateClientConnectionStatus(string clientId, bool isConnected)
        {
            GetOrCreateClientStream(clientId).connected = isConnected;
            GetOrCreateClientStream(clientId).isHost = (clientId == GetHostClientId());
        }

        public override void UpdateClientPose(string clientId, Pose pose)
        {
            GetOrCreateClientStream(clientId).clientPose = pose;

            minimapRenderer.UpdateClientPose(clientId, pose);
        }

        public override void UpdateRegisteredImageCount(int registeredImageCount)
        {
            _registeredImageCount = registeredImageCount;
        }

        public override void RenderPointCloudsBatch(IDictionary<string, Vector3[]> pointsBatch)
        {
            if (pointCloudRenderer != null)
            {
                pointCloudRenderer.SetNewBatch();
                foreach (var (clientId, points) in pointsBatch)
                {
                    if (points != null && points.Length > 0)
                    {
                        pointCloudRenderer.RenderPoints(clientId, points, _currentClientId == clientId);
                    }

                    GetOrCreateClientStream(clientId).points = points;
                }
            }
        }

        public override void RenderImmediateMesh(MeshRenderable meshRenderable)
        {
            if (immediateMeshRenderer != null)
            {
                immediateMeshRenderer.RenderMeshObject(meshRenderable);
            }
            if (minimapMeshRenderer != null)
            {
                minimapMeshRenderer.RenderMeshObject(meshRenderable);
            }
        }

        public override bool ShouldRenderStaticMesh()
        {
            return staticMeshRenderer != null;
        }

        public override void RenderStaticMesh(MeshRenderable meshRenderable)
        {
            if (staticMeshRenderer != null)
            {
                staticMeshRenderer.RenderMeshObject(meshRenderable);
            }
        }

        public override void RenderNavigationMesh(MeshRenderable meshRenderable)
        {
            if (navMeshRenderer != null)
            {
                navMeshRenderer.RenderMeshObject(meshRenderable);
            }
        }

        public override void RenderTrajectory(string clientId, Pose[] trajectory)
        {
            if (trajectoryRenderer != null)
            {
                if (trajectory != null && trajectory.Length > 0)
                {
                    trajectoryRenderer.RenderTrajectory(clientId, trajectory, _currentClientId == clientId);
                }
                GetOrCreateClientStream(clientId).trajectory = trajectory;
            }
        }

        public override void RenderAirWall()
        {
            if (airWallRenderer != null)
            {
                airWallRenderer.RenderAirWall();
            }
        }

        public override void RenderImmediateDetectedObjects(ObjectDetectionResult objectDetection)
        {
            if (immediateBoxRenderer != null)
            {
                immediateBoxRenderer.RenderDetectedBoxes(objectDetection.boxDetections);
            }
        }

        public override void RenderStaticDetectedObjects(ObjectDetectionResult objectDetection)
        {
            if (staticBoxRenderer != null)
            {
                staticBoxRenderer.RenderDetectedBoxes(objectDetection.boxDetections);
            }
        }

        public override RaycastHitResult? RenderRaycastCursor(Matrix4x4 localToSceneTransform)
        {
            if (raycastRenderer != null)
            {
                return raycastRenderer.RenderRaycastCursor(localToSceneTransform);
            }
            else
            {
                return null;
            }
        }

        public override void ShowMarker(MarkerRenderable markerRenderable)
        {
            if (markerRenderer != null)
            {
                markerRenderer.RenderQrCodeImage(markerRenderable);
            }
        }

        public override void HideMarker()
        {
            if (markerRenderer != null)
            {
                markerRenderer.HideQrCodeImage();
            }
        }

        public override void CleanImmediate()
        {
            if (_allClientStreams != null)
            {
                _allClientStreams.Clear();
            }
            if (pointCloudRenderer != null)
            {
                pointCloudRenderer.ClearBuffers();
            }
            if (immediateMeshRenderer != null)
            {
                immediateMeshRenderer.Clear();
            }
            if (minimapMeshRenderer != null)
            {
                minimapMeshRenderer.Clear();
            }
            if (immediateBoxRenderer != null)
            {
                immediateBoxRenderer.ClearAllBoxes();
            }
            if (trajectoryRenderer != null)
            {
                trajectoryRenderer.ClearAll();
            }
            if (minimapRenderer != null)
            {
                minimapRenderer.ClearAll();
            }
            _currentClientId = null;
            _hostClientId = null;
        }

        public override void CleanStatic()
        {
            if (staticMeshRenderer != null)
            {
                staticMeshRenderer.ResetRenderer();
            }
            if (navMeshRenderer != null)
            {
                navMeshRenderer.ResetRenderer();
            }
            if (airWallRenderer != null)
            {
                airWallRenderer.ResetRenderer();
            }
            if (staticBoxRenderer != null)
            {
                staticBoxRenderer.ClearAllBoxes();
            }
        }

        public override void CleanAll()
        {
            CleanImmediate();
            CleanStatic();
        }

        public override string GetCurrentClientId()
        {
            return _currentClientId;
        }

        public override string GetHostClientId()
        {
            return _hostClientId;
        }

        public override bool IsCurrentDeviceHost()
        {
            return _hostClientId != null && _currentClientId == _hostClientId;
        }

        public override Pose? GetRaycastCursorPose()
        {
            if (raycastRenderer != null)
            {
                return raycastRenderer.GetCursorPose();
            }
            return null;
        }

        public override GameObject GetStaticMeshObject()
        {
            if (staticMeshRenderer != null)
            {
                return staticMeshRenderer.GetMeshObject();
            }
            return null;
        }
        
        public override GameObject GetNavMeshObject()
        {
            if (navMeshRenderer != null)
            {
                return navMeshRenderer.GetMeshObject();
            }
            return null;
        }

        public override SceneStreamRenderable GetStreamRenderable()
        {
            SceneStreamRenderable streamRenderable = new SceneStreamRenderable();
            streamRenderable.sharedOriginOffset = new Pose(immediateRoot.transform.position, immediateRoot.transform.rotation);
            streamRenderable.currentClientId = GetCurrentClientId();
            streamRenderable.clientStreams = _allClientStreams;
            streamRenderable.immediateMesh = GetImmediateMesh();
            streamRenderable.registeredImageCount = _registeredImageCount;
            return streamRenderable;
        }

        private ClientStreamRenderable GetOrCreateClientStream(string clientId)
        {
            if (!_allClientStreams.ContainsKey(clientId))
            {
                ClientStreamRenderable client = new();
                client.clientId = clientId;
                client.connected = true;
                client.isHost = false;
                client.clientPose = null;
                _allClientStreams[clientId] = client;
            }
            return _allClientStreams[clientId];
        }

        private Mesh GetImmediateMesh()
        {
            if (immediateMeshRenderer != null)
            {
                MeshFilter meshFilter = immediateMeshRenderer.gameObject.GetComponent<MeshFilter>();
                if (meshFilter != null)
                {
                    return meshFilter.mesh;
                }
            }
            return null;
        }
    }
}
